//
//  AAMVA_Barcode_Paser.h
//  AAMVA Barcode Paser
//
//  Created by Jakub Dolejs on 19/12/2019.
//  Copyright © 2019 Applied Recognition Inc. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for AAMVA_Barcode_Paser.
FOUNDATION_EXPORT double AAMVA_Barcode_PaserVersionNumber;

//! Project version string for AAMVA_Barcode_Paser.
FOUNDATION_EXPORT const unsigned char AAMVA_Barcode_PaserVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <AAMVA_Barcode_Paser/PublicHeader.h>


